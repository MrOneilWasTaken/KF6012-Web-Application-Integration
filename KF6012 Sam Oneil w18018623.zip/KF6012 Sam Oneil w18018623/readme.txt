KF6012 Assignment

This is student work and is not associated with the DIS

Sam Oneil w18018623

Part 1
http://unn-w18018623.newnumyspace.co.uk/kf6012/coursework/part1/

Part 2
http://unn-w18018623.newnumyspace.co.uk/kf6012/coursework/part2/

Additional notes:
Because of the way newnumyspace is set up, when logging in my code refreshes the page
and leads to a page not found error. If you navigate back to the root page (http://unn-w18018623.newnumyspace.co.uk/kf6012/coursework/part2/)
and re-navigate to Reading List page, it will display accurately with the logged in account