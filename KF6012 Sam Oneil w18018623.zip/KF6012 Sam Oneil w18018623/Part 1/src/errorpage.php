<?php 
/**
 * Error page
 * 
 * This class acts as a unique class so the error page is unique
 *  
 * @author Sam Oneil w18018623
 */
    class ErrorPage extends WebPage
    {   
    }
?>