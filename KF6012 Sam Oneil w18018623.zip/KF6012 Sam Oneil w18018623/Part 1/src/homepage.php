<?php
/**
 * Home page
 * 
 * This class acts as a unique class so the home page is unique
 *  
 * @author Sam Oneil w18018623
 *  
 */
class HomePage extends WebPage
{
}
