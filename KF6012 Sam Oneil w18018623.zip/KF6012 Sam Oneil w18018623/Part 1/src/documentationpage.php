<?php  
/**
 * Documentation page
 * 
 * This class acts as a unique class so the documentation page is unique
 *  
 * @author Sam Oneil w18018623
 *  
 */
    class DocumentationPage extends Webpage
    {
         
    }
